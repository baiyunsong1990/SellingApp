//
//  OrderEditView.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/23.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class OrderEditView:UIView {
    
    var id:Int = 0
    var pay:Double = 0 //付款
    var price:Double = 0 //原价
    var type:Int = 0
    
    var priceLabel = UILabel()
    var txtView = UITextField()
    
    let SCREEN_WIDTH = UIScreen.main.bounds.width
    let SCREEN_HEIGHT = UIScreen.main.bounds.height
    
    let CORNUS = 5.0
    
    let colorList = ColorList()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let priceView = UIView()

        priceView.frame = CGRect(x: 0, y: 0, width: 220, height: 120)
        priceView.center = CGPoint(x: SCREEN_WIDTH/2, y: SCREEN_HEIGHT*0.45)
        priceView.backgroundColor = UIColor.white
        priceView.layer.borderWidth = 3
        priceView.layer.borderColor = colorList.popViewBgColor.cgColor
        //priceView.layer.cornerRadius = 10.0

        
        let titleView = UIView()
        titleView.frame = CGRect(x: 0, y: 0, width: 220, height: 30)
        titleView.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "title_bg"))
        //设置左上右上圆角
        let maskPath = UIBezierPath(roundedRect: titleView.bounds, byRoundingCorners: [UIRectCorner.topLeft, UIRectCorner.topRight], cornerRadii: CGSize(width: CORNUS, height: CORNUS))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = titleView.bounds
        maskLayer.path = maskPath.cgPath
        titleView.layer.mask = maskLayer
        
        priceLabel = UILabel(frame: CGRect(x: 10, y: 0, width: 200, height: 30))
        priceLabel.font = UIFont.systemFont(ofSize: 14)
        priceLabel.textColor = UIColor.white
        priceLabel.textAlignment = .center
      
        titleView.addSubview(priceLabel)
        
        txtView = UITextField(frame: CGRect(x: 20, y: 50, width: 180, height: 20))
        txtView.font = UIFont.systemFont(ofSize: 12)
        txtView.textAlignment = .center
        txtView.keyboardType = .decimalPad
        txtView.layer.borderWidth = 1.0
        txtView.layer.borderColor = colorList.borderGreyColor.cgColor
        
        priceView.addSubview(titleView)
        priceView.addSubview(txtView)
       
        
        let btnConfirm = UIButton(frame:CGRect(x: 0, y: 93, width: 110, height: 24))
        btnConfirm.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "btn_bg1"))
        btnConfirm.setTitle("确定", for: .normal)
        btnConfirm.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        //左下圆角
        let maskPath_left = UIBezierPath(roundedRect: btnConfirm.bounds, byRoundingCorners: [UIRectCorner.bottomLeft], cornerRadii: CGSize(width: CORNUS, height: CORNUS))
        let maskLayer_left = CAShapeLayer()
        maskLayer_left.frame = btnConfirm.bounds
        maskLayer_left.path = maskPath_left.cgPath
        
        btnConfirm.layer.mask = maskLayer_left
        btnConfirm.addTarget(self, action: #selector(dismiss(sender:)), for: .touchUpInside)
        
        priceView.addSubview(btnConfirm)
        
        let btnCancel = UIButton(frame:CGRect(x: 110, y: 93, width: 110, height: 24))
        btnCancel.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "btn_bg1"))
        btnCancel.setTitle("取消", for: .normal)
        btnCancel.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        //右下圆角
        let maskPath_right = UIBezierPath(roundedRect: btnCancel.bounds, byRoundingCorners: [UIRectCorner.bottomRight], cornerRadii: CGSize(width: CORNUS, height: CORNUS))
        let maskLayer_right = CAShapeLayer()
        maskLayer_right.frame = btnCancel.bounds
        maskLayer_right.path = maskPath_right.cgPath
        
        btnCancel.layer.mask = maskLayer_right
        btnCancel.addTarget(self, action: #selector(dismiss(sender:)), for: .touchUpInside)
        
        priceView.addSubview(btnCancel)
        
        addSubview(priceView)
        

    }
    
    func dismiss(sender:UIButton?) {
        if (sender?.titleLabel?.text == "确定") {
            if (txtView.text=="" && type<2)  {
                txtView.layer.borderColor = UIColor.red.cgColor
                txtView.becomeFirstResponder()
            } else {
                let loadData = LoadData()
                switch type {
                case 0:
                    loadData.updateOrderPay(id: id, state: "待发货", pay: txtView.text!)
                case 1:
                    loadData.updateOrderProfit(id: id, state: "待收货", postage: txtView.text!, profit: String(pay-price-Double(txtView.text!)!))
                case 2:
                    loadData.updateOrderStatus(id: id, state: "已收货")
                default:
                    break
                }
            }
        }

        /*var table = UITableView()
        let v = self.superview
        let order:OrderInfo = v?.superclass as! OrderInfo
        order.data = order.db.query(sql: "select * from tb_order")
        table = v?.viewWithTag(10) as! UITableView
        table.reloadData()*/
        
        removeFromSuperview()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
