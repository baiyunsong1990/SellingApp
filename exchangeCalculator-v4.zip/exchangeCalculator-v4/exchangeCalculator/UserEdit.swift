//
//  UserEdit.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/19.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class UserEdit: UIViewController {
    
    var txtName = UITextField()
    var txtID = UITextField()
    var txtPhone = UITextField()
    var txtAddress = UITextView()
    
    var uid = ""
    var name = ""
    var id = ""
    var phone = ""
    var address = ""
    var type = "" //添加/修改
    
    let SCREEN_WIDTH = Int(UIScreen.main.bounds.width)
    let SCREEN_HEIGHT = Int(UIScreen.main.bounds.height)
    
    let LEFT_MARGIN = 20
    let LABEL_WIDTH = 100
    let TEXT_HEIGHT = 30
    
    let colorList = ColorList()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "保存", style: UIBarButtonItemStyle.plain, target: self, action: #selector(save(sender:)))
        
        
        let userView = UIView(frame: CGRect(x: LEFT_MARGIN, y: 80, width: SCREEN_WIDTH, height: SCREEN_HEIGHT-80))
        
        let lblUID = UILabel(frame: CGRect(x: 0, y: 0, width: LABEL_WIDTH, height: TEXT_HEIGHT))
        lblUID.text = "用户" + uid
        lblUID.textColor = UIColor.black
        lblUID.font = UIFont.systemFont(ofSize: 16)
        lblUID.textAlignment = NSTextAlignment.right
        userView.addSubview(lblUID)
        
        let lblName = UILabel(frame: CGRect(x: 0, y: TEXT_HEIGHT+10, width: LABEL_WIDTH, height: TEXT_HEIGHT))
        lblName.text = "用户名："
        lblName.textColor = UIColor.black
        lblName.font = UIFont.systemFont(ofSize: 16)
        lblName.textAlignment = NSTextAlignment.right
        userView.addSubview(lblName)
        
        txtName.frame = CGRect(x: LABEL_WIDTH, y: TEXT_HEIGHT+10, width: SCREEN_WIDTH-LEFT_MARGIN*2-LABEL_WIDTH, height: TEXT_HEIGHT)
        txtName.text = name
        txtName.font = UIFont.systemFont(ofSize: 16)
        txtName.textColor = colorList.textGrayColor
        txtName.borderStyle = UITextBorderStyle.roundedRect
        txtName.layer.borderColor = colorList.borderBlueColor.cgColor
        txtName.layer.borderWidth = 1.0
        txtName.layer.cornerRadius = 5
        userView.addSubview(txtName)
        
        let lblID = UILabel(frame: CGRect(x: 0, y: (TEXT_HEIGHT+10)*2, width: LABEL_WIDTH, height: TEXT_HEIGHT))
        lblID.text = "身份证号："
        lblID.font = UIFont.systemFont(ofSize: 16)
        lblID.textAlignment = NSTextAlignment.right
        userView.addSubview(lblID)
        
        txtID.frame = CGRect(x: LABEL_WIDTH, y: (TEXT_HEIGHT+10)*2, width: SCREEN_WIDTH-LEFT_MARGIN*2-LABEL_WIDTH, height: TEXT_HEIGHT)
        txtID.text = id
        txtID.font = UIFont.systemFont(ofSize: 16)
        txtID.textColor = colorList.textGrayColor
        txtID.borderStyle = UITextBorderStyle.roundedRect
        txtID.layer.borderColor = colorList.borderBlueColor.cgColor
        txtID.layer.borderWidth = 1.0
        txtID.layer.cornerRadius = 5
        userView.addSubview(txtID)
        
        let lblPhone = UILabel(frame: CGRect(x: 0, y: (TEXT_HEIGHT+10)*3, width: LABEL_WIDTH, height: TEXT_HEIGHT))
        lblPhone.text = "电话："
        lblPhone.font = UIFont.systemFont(ofSize: 16)
        lblPhone.textAlignment = NSTextAlignment.right
        userView.addSubview(lblPhone)
        
        txtPhone.frame = CGRect(x: LABEL_WIDTH, y: (TEXT_HEIGHT+10)*3, width: SCREEN_WIDTH-LEFT_MARGIN*2-LABEL_WIDTH, height: TEXT_HEIGHT)
        txtPhone.text = phone
        txtPhone.font = UIFont.systemFont(ofSize: 16)
        txtPhone.textColor = colorList.textGrayColor
        txtPhone.borderStyle = UITextBorderStyle.roundedRect
        txtPhone.keyboardType = UIKeyboardType.numberPad
        txtPhone.layer.borderColor = colorList.borderBlueColor.cgColor
        txtPhone.layer.borderWidth = 1.0
        txtPhone.layer.cornerRadius = 5
        userView.addSubview(txtPhone)
        
        let lblAddress = UILabel(frame: CGRect(x: 0, y: (TEXT_HEIGHT+10)*4, width: LABEL_WIDTH, height: TEXT_HEIGHT))
        lblAddress.text = "地址："
        lblAddress.font = UIFont.systemFont(ofSize: 16)
        lblAddress.textAlignment = NSTextAlignment.right
        userView.addSubview(lblAddress)
        
        txtAddress.frame = CGRect(x: LABEL_WIDTH, y: (TEXT_HEIGHT+10)*4, width: SCREEN_WIDTH-LEFT_MARGIN*2-LABEL_WIDTH, height: TEXT_HEIGHT*3)
        txtAddress.text = address
        txtAddress.font = UIFont.systemFont(ofSize: 16)
        txtAddress.textColor = colorList.textGrayColor
        txtAddress.layer.borderColor = colorList.borderBlueColor.cgColor
        txtAddress.layer.borderWidth = 1
        txtAddress.layer.cornerRadius = 5
        
        userView.addSubview(txtAddress)
    
        self.view.addSubview(userView)
        
    }
    
    func save(sender:UIBarButtonItem) {
        let loadData = LoadData()
        if (type == "insert") {
            if (txtName.text==""){
                txtName.placeholder = "请输入用户名"
                txtName.layer.borderColor = UIColor.red.cgColor
                txtName.becomeFirstResponder()
            } else if (txtID.text == "") {
                txtID.placeholder = "请输入身份证号"
                txtID.layer.borderColor = UIColor.red.cgColor
                txtID.becomeFirstResponder()
                txtName.layer.borderColor = colorList.borderBlueColor.cgColor
            } else {
                loadData.insertUser(name: txtName.text!, id: txtID.text!, phone: txtPhone.text!, address: txtAddress.text)
                self.hidesBottomBarWhenPushed = false
                self.navigationController?.popViewController(animated: true)
                
            }
        } else if (type == "update") {
            loadData.updateUser(uid: Int(uid)!, name: txtName.text!, id: txtID.text!, phone: txtPhone.text!, address: txtAddress.text)
            self.hidesBottomBarWhenPushed = false
            self.navigationController?.popViewController(animated: true)
            
        }
        
        /*let alert = UIAlertView(title: "", message: "添加成功", delegate: nil, cancelButtonTitle: nil)
         alert.alertViewStyle = UIAlertViewStyle.plainTextInput
         
         alert.show()*/
        
    }
}
