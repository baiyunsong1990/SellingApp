//
//  ColorList.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/17.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class ColorList {
    
    let itemTextColor = UIColor(red: 20/255, green: 90/255, blue: 149/255, alpha: 1.0)
    let textGrayColor = UIColor(red: 110/255, green: 110/255, blue: 110/255, alpha: 1.0)
    let itemBtnColor = UIColor(red: 6/255, green: 122/255, blue: 190/255, alpha: 1.0)
    let itemBtnGrayColor = UIColor(red: 117/255, green: 137/255, blue: 149/255, alpha: 1.0)
    let textDarkBlueColor = UIColor(red: 53/255, green: 71/255, blue: 86/255, alpha: 1.0)
    let greyColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1.0)
    let borderGreyColor = UIColor(red: 180/255, green: 180/255, blue: 180/255, alpha: 1.0)
    let priceOrangeColor = UIColor(red: 216/255, green: 74/255, blue: 19/255, alpha: 1.0)
    let borderBlueColor = UIColor(red: 197/255, green: 227/255, blue: 240/255, alpha: 1.0)
    let buttonBgColor = UIColor(red: 57/255, green: 114/255, blue: 161/255, alpha: 1.0)
    let buttonTabColor = UIColor(red: 141/255, green: 178/255, blue: 209/255, alpha: 1.0)
    let popViewBgColor = UIColor(red: 64/255, green: 116/255, blue: 158/255, alpha: 1.0)
}
