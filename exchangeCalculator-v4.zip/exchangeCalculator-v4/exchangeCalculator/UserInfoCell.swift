//
//  UserInfo.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/20.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class UserInfoCell:UIView {
    
    let userImg = UIImageView()
    let lblName = UILabel() //用户名
    let lblID = UILabel() //身份证号
    let lblPhone = UILabel() //电话
    let lblAddress = UILabel() //地址
    
    let SCREEN_WIDTH = Int(UIScreen.main.bounds.width)
    let SCREEN_HEIGHT = Int(UIScreen.main.bounds.height)
    let LEFT_SPACE = 80
    
    let colorList = ColorList()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        userImg.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        userImg.image = UIImage(named: "user")
        
        lblName.frame = CGRect(x: 5, y: 36, width: SCREEN_WIDTH, height: 22)
        lblName.textColor = colorList.itemTextColor
        lblName.font = UIFont.systemFont(ofSize: 16)
        
        lblID.frame = CGRect(x: LEFT_SPACE, y: 0, width: SCREEN_WIDTH, height: 18)
        lblID.textColor = colorList.textGrayColor
        lblID.font = UIFont.systemFont(ofSize: 12)
        
        lblPhone.frame = CGRect(x: LEFT_SPACE, y: 18, width: SCREEN_WIDTH, height: 18)
        lblPhone.textColor = colorList.textGrayColor
        lblPhone.font = UIFont.systemFont(ofSize: 12)
        
        lblAddress.frame = CGRect(x: LEFT_SPACE, y: 36, width: SCREEN_WIDTH, height: 18)
        lblAddress.textColor = colorList.textGrayColor
        lblAddress.font = UIFont.systemFont(ofSize: 12)
        
        addSubview(userImg)
        addSubview(lblName)
        addSubview(lblID)
        addSubview(lblPhone)
        addSubview(lblAddress)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
