//
//  LoadData.swift
//  priceCalcuator
//
//  Created by apple on 2016/12/6.
//  Copyright © 2016年 apple. All rights reserved.
//

import Foundation

class LoadData  {
    
    var db:SQLiteDB! = SQLiteDB.sharedInstance
    
    func createTable() {
        let result = db.execute(sql: "create table if not exists tb_category(id integer primary key,category varchar(30), tablename varchar(30))")
        print(result)
        //女性保健
        db.execute(sql: "create table if not exists tb_beauty(id integer primary key,sub_category varchar(50),item_name varchar(100),item_price varchar(10),favourite char(1))")
        //母婴产品
        db.execute(sql: "create table if not exists tb_maternal(id integer primary key,sub_category varchar(50),item_name varchar(100),item_price varchar(10),favourite char(1))")
        //日常保健
        db.execute(sql: "create table if not exists tb_healthcare(id integer primary key,sub_category varchar(50),item_name varchar(100),item_price varchar(10),favourite char(1))")
        //女性保健
        db.execute(sql: "create table if not exists tb_women(id integer primary key,sub_category varchar(50),item_name varchar(100),item_price varchar(10),favourite char(1))")
        //奶粉系列
        db.execute(sql: "create table if not exists tb_milkpowder(id integer primary key,sub_category varchar(50),item_name varchar(100),item_price varchar(10),favourite char(1))")
        //其他
        db.execute(sql: "create table if not exists tb_custom(id integer primary key,sub_category varchar(50),item_name varchar(100),item_price varchar(10))")
        
    }
    
    func insertCategory() {
        db.execute(sql: "insert into tb_category(category,tablename) values('美容保健','beauty')")
        db.execute(sql: "insert into tb_category(category,tablename) values('母婴产品','maternal')")
        db.execute(sql: "insert into tb_category(category,tablename) values('日常保健','healthcare')")
        db.execute(sql: "insert into tb_category(category,tablename) values('女性保健','women')")
        db.execute(sql: "insert into tb_category(category,tablename) values('奶粉制品','milkpowder')")
        db.execute(sql: "insert into tb_category(category,tablename) values('自定义','custom')")
    }
    
    func insertItem(category:String,sub_category:String) {
        let cInfo = CommodityInfo()

        let new_category = sub_category.replacingOccurrences(of: " ", with: "%20")
        let commodityArr:NSArray=cInfo.getInfo("http://www.chemistwarehouse.com.au/search?searchtext="+new_category+"&searchmode=allwords")
        
        for i in 0..<commodityArr.count{
            
            var commodity:NSMutableArray=commodityArr[i] as! NSMutableArray
            //替换单引号，sql中两个单引号表示一个单引号
            commodity[0] = (commodity[0] as! String).replacingOccurrences(of: "&#39;", with: "''")
            
            insertData(table: category, sub_category: sub_category, item_name: commodity[0] as! String, item_price: commodity[1] as! String,favourite: "0")
            
        }
    }
    
    //添加商品信息
    private func insertData(table:String,sub_category:String,item_name:String,item_price:String,favourite:String) {
        let sql = "insert into tb_\(table)(sub_category,item_name,item_price,favourite) values('\(sub_category)','\(item_name)','\(item_price)','\(favourite)')"
        
        db.execute(sql: sql)
    }
    
    func loadUser() {

        db.execute(sql: "create table if not exists tb_user(uid integer primary key,name varchar(30),id varchar(18), phone varchar(15),address varchar(200))")
    }
    
    func insertUser(name:String,id:String,phone:String,address:String) {
        let sql = "insert into tb_user(name,id,phone,address) values('\(name)','\(id)','\(phone)','\(address)')"
        db.execute(sql: sql)
    }
    
    func updateUser(uid:Int,name:String,id:String,phone:String,address:String) {
        let sql = "update tb_user set name='\(name)',id='\(id)',phone='\(phone)',address='\(address)' where uid=\(uid)"
        db.execute(sql: sql)
    }
    
    func deleteUser(id:String) {
        
        let sql = "delete from tb_user where id = '\(id)'"
        db.execute(sql:sql)
    }
    
    func loadOrder() {
        db = SQLiteDB.sharedInstance
        let sql = "create table if not exists tb_order(id integer primary key,user varchar(30),item varchar(50),price varchar(20),date varchar(50),state varchar(10),pay varchar(10),postage varchar(10),profit varchar(10))"
        db.execute(sql:sql)
    }
    
    func insertOrder(name:String,item:String,price:String,date:String) {
        db = SQLiteDB.sharedInstance
        let sql = "insert into tb_order(user,item,price,date,state,pay,postage,profit) values('\(name)','\(item)','\(price)','\(date)','待付款','-','-','-')"
        db.execute(sql:sql)
    }
    
    func updateOrderPay(id:Int,state:String,pay:String) {
        db = SQLiteDB.sharedInstance

        let sql = "update tb_order set state='\(state)', pay='\(pay)' where id=\(id)"
        db.execute(sql:sql)
    }
    
    func updateOrderProfit(id:Int,state:String,postage:String,profit:String) {
        let sql = "update tb_order set state='\(state)', postage='\(postage)', profit='\(profit)' where id=\(id)"
        db.execute(sql:sql)
    }
    
    func updateOrderStatus(id:Int,state:String) {
        let sql = "update tb_order set state='\(state)' where id=\(id)"
        db.execute(sql:sql)
    }
    
    func deleteOrder(id:Int) {

        let sql = "delete from tb_order where id = \(id)"
        db.execute(sql:sql)
    }

    
    func clearTable(table_name:String){
        db = SQLiteDB.sharedInstance
        let result = db.execute(sql: "delete from \(table_name)")
        print(result)
    }
    
    func deleteTable(table_name:String) {
        db = SQLiteDB.sharedInstance
        let result = db.execute(sql: "drop table \(table_name)")
        print(result)
    }
}
