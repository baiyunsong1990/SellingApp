//
//  OrderCell.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/22.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class OrderCell:UIView {
    
    var nameLabel = UILabel()
    var dateLabel = UILabel()
    var stateLabel = UILabel()
    
    var payLabel = UILabel()
    var postageLabel = UILabel()
    var profitLabel = UILabel()
    
    //var priceLabel = UILabel()
    var detailButton = UIButton()
    var clickButton = UIButton()
    
    let SCREEN_WIDTH = Int(UIScreen.main.bounds.width)
    let SCREEN_HEIGHT = Int(UIScreen.main.bounds.height)
    
    let colorList = ColorList()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        nameLabel.frame = CGRect(x: 20, y: 10, width: 60, height: 20)
        nameLabel.font = UIFont.systemFont(ofSize: 16)
        
        dateLabel.frame = CGRect(x: 80, y: 10, width: 100, height: 20)
        dateLabel.font = UIFont.systemFont(ofSize: 12)
        dateLabel.textColor = colorList.textGrayColor
        
        stateLabel.frame = CGRect(x: SCREEN_WIDTH-80, y: 10, width: 60, height: 20)
        stateLabel.font = UIFont.systemFont(ofSize: 12)
        stateLabel.textColor = colorList.textGrayColor
        
        let payTitle = UILabel(frame: CGRect(x: 20, y: 35, width: Int((SCREEN_WIDTH-40)/3), height: 20))
        payTitle.text = "金额"
        payTitle.font = UIFont.systemFont(ofSize: 14)
        payTitle.textColor = colorList.textDarkBlueColor
        payTitle.textAlignment = NSTextAlignment.left
        
        payLabel.frame = CGRect(x: 20, y: 55, width: Int((SCREEN_WIDTH-40)/3), height: 20)
        payLabel.font = UIFont(name: "Snell Roundhand", size: 18)
        
        let postageTitle = UILabel(frame: CGRect(x: 20+Int((SCREEN_WIDTH-40)/3), y: 35, width: Int((SCREEN_WIDTH-40)/3), height: 20))
        postageTitle.text = "邮费"
        postageTitle.font = UIFont.systemFont(ofSize: 14)
        postageTitle.textAlignment = NSTextAlignment.left
        postageTitle.textColor = colorList.textDarkBlueColor
        
        postageLabel.frame = CGRect(x: 20+Int((SCREEN_WIDTH-40)/3), y: 55, width: Int((SCREEN_WIDTH-40)/3), height: 20)
        postageLabel.font = UIFont(name: "Snell Roundhand", size: 18)
        
        let profitTitle = UILabel(frame: CGRect(x: 20+Int((SCREEN_WIDTH-40)/3)*2, y: 35, width: Int((SCREEN_WIDTH-40)/3), height: 20))
        profitTitle.text = "利润"
        profitTitle.font = UIFont.systemFont(ofSize: 14)
        profitTitle.textAlignment = NSTextAlignment.left
        profitTitle.textColor = colorList.textDarkBlueColor
        
        profitLabel.frame = CGRect(x: 20+Int((SCREEN_WIDTH-40)/3)*2, y: 55, width: Int((SCREEN_WIDTH-40)/3), height: 20)
        profitLabel.font = UIFont(name: "Snell Roundhand", size: 18)
        profitLabel.textColor = colorList.itemTextColor
        
        /*priceLabel.frame = CGRect(x: SCREEN_WIDTH-180, y: 80, width: 100, height: 22)
        priceLabel.font = UIFont.systemFont(ofSize: 14)
        priceLabel.textColor = colorList.priceOrangeColor*/
        
        clickButton = UIButton(frame:CGRect(x: SCREEN_WIDTH-150, y: 90, width: 50, height: 20))
        clickButton.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        clickButton.layer.backgroundColor = colorList.buttonBgColor.cgColor
        clickButton.layer.cornerRadius = 5
        
        detailButton.frame = CGRect(x: SCREEN_WIDTH-90, y: 90, width: 60, height: 20)
        detailButton.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        detailButton.setTitle("查看", for: .normal)
        detailButton.layer.backgroundColor = colorList.textDarkBlueColor.cgColor
        detailButton.layer.cornerRadius = 5
        
        addSubview(nameLabel)
        addSubview(dateLabel)
        addSubview(stateLabel)
        
        addSubview(payTitle)
        addSubview(payLabel)
        addSubview(postageTitle)
        addSubview(postageLabel)
        addSubview(profitTitle)
        addSubview(profitLabel)
        
        addSubview(detailButton)
        addSubview(clickButton)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
