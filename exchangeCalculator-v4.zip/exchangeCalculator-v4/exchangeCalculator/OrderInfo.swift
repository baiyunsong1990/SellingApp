//
//  OrderInfo.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/21.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class OrderInfo:UIViewController,UITableViewDataSource, UITableViewDelegate {
    
    var db:SQLiteDB!
    var data:[[String:Any]] = [[:]]
    
    var dataList:[String]?
    var tabView = UIView()
    var tableView = UITableView()
    
    let SCREEN_WIDTH = Int(UIScreen.main.bounds.width)
    let SCREEN_HEIGHT = Int(UIScreen.main.bounds.height)
    let CELL_HEIGHT:CGFloat = 115.0
    
    let loadData = LoadData()
    let colorList = ColorList()
    
    var newView = OrderEditView()
    
    //进入页面前加载，更新数据库及列表
    override func viewWillAppear(_ animated: Bool) {

        db = SQLiteDB.sharedInstance
        data = db.query(sql: "select * from tb_order")
        
        self.navigationItem.title = "订单管理"
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "nav_bg"), for: .default)
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.titleView?.tintColor = UIColor.white
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white] //标题颜色
        
        //顶部导航
        let btnTitle = ["全部","待付款","待发货","待收货","历史订单"]
        tabView.frame = CGRect(x: 0, y: 65, width: SCREEN_WIDTH, height: 34)
        tabView.backgroundColor = colorList.greyColor
        for i in 0...4 {
            let button = UIButton()
            button.frame = CGRect(x: SCREEN_WIDTH/5*i, y: 5, width: SCREEN_WIDTH/5, height: 18)
            button.setTitle(btnTitle[i], for: .normal)
            button.setTitleColor(UIColor.black, for: .normal)
            button.setTitleColor(colorList.itemTextColor, for: .selected)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
            button.addTarget(self, action: #selector(changeTab(sender:)), for: .touchUpInside)
            tabView.addSubview(button)
        }
        self.view.addSubview(tabView)
        //第一个tag选中
        let button:UIButton = tabView.subviews[0] as! UIButton
        button.isSelected = true
        
        self.tableView = UITableView(frame: CGRect(x: 10, y: 106, width: SCREEN_WIDTH, height: SCREEN_HEIGHT-20), style: UITableViewStyle.plain)
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.tag = 10
        self.view.addSubview(tableView)
        
        print("ddd")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        db = SQLiteDB.sharedInstance
        data = db.query(sql: "select * from tb_order")
    }

    //每个分组对应的cell个数
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return CELL_HEIGHT
    }
    
    //创建Cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "td")
        cell.selectionStyle = UITableViewCellSelectionStyle.none //禁止cell点击事件
        
        let orderCell = OrderCell(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH-40, height: SCREEN_HEIGHT-40))
        orderCell.nameLabel.text = data[indexPath.row]["user"] as! String?
        orderCell.dateLabel.text = data[indexPath.row]["date"] as! String?
        orderCell.stateLabel.text = data[indexPath.row]["state"] as! String?
        
        orderCell.payLabel.text = data[indexPath.row]["pay"] as! String?
        orderCell.postageLabel.text = data[indexPath.row]["postage"] as! String?
        orderCell.profitLabel.text = data[indexPath.row]["profit"] as! String?
        
        //orderCell.priceLabel.text = data[indexPath.row]["price"] as! String?
        orderCell.clickButton.setTitle(getButtonTitle(state: (data[indexPath.row]["state"] as! String?)!), for: .normal)
        orderCell.clickButton.layer.backgroundColor = getButtonColor(state: (data[indexPath.row]["state"] as! String?)!)
        orderCell.clickButton.tag = indexPath.row + 100
        orderCell.clickButton.addTarget(self, action: #selector(btnclick(sender:)), for: .touchUpInside)
        orderCell.detailButton.addTarget(self, action: #selector(viewDetail(sender:)), for: .touchUpInside)
        orderCell.detailButton.tag = indexPath.row + 1000
        
        
        cell.addSubview(orderCell)

        return cell
    }
    
    //返回编辑类型，滑动删除
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        let id:Int = (data[indexPath.row]["id"] as! Int?)!
        loadData.deleteOrder(id: id)
        return UITableViewCellEditingStyle.delete
    }
    
    //在这里修改删除按钮的文字
    func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
        return "删除"
    }
    
    //点击删除按钮的响应方法，在这里处理删除的逻辑
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete {
            self.data.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath as IndexPath], with: UITableViewRowAnimation.fade)
        }
    }
    
    //点击按钮，付款
    func btnclick(sender:UIButton?) {
        newView = OrderEditView(frame: self.view.bounds)
        newView.id = data[(sender?.tag)!-100]["id"] as! Int
        newView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.6)
        newView.alpha = 0
        if (sender?.titleLabel?.text == "付款") {
            newView.priceLabel.text = "请输入付款金额"
            newView.type = 0
        } else if (sender?.titleLabel?.text == "发货") {
            newView.priceLabel.text = "请输入邮费"
            newView.type = 1
            newView.pay = Double(data[(sender?.tag)!-100]["pay"] as! String)!
            newView.price = Double(data[(sender?.tag)!-100]["price"] as! String)!
        } else if (sender?.titleLabel?.text == "收货") {
            newView.priceLabel.text = "确认收货"
            newView.txtView.removeFromSuperview()
            newView.type = 2
        }
        //添加半透明层
        var currentWindow = UIWindow()
        currentWindow = UIApplication.shared.keyWindow!
        currentWindow.addSubview(newView)
        UIView.animate(withDuration: 0.2, animations: alphaDown)
    }
    
    func alphaDown() {
        newView.alpha = 1
    }
    
    //设置不同订单状态的按钮标题
    func getButtonTitle(state:String) -> String {
        switch state {
        case "待付款":
            return "付款"
        case "待发货":
            return "发货"
        case "待收货":
            return "收货"
        default:
            return ""
        }
    }
    
    //设置不同订单状态的按钮颜色
    func getButtonColor(state:String) -> CGColor {
        switch state {
        case "待付款":
            return colorList.buttonBgColor.cgColor
        case "待发货":
            return colorList.priceOrangeColor.cgColor
        case "待收货":
            return colorList.buttonTabColor.cgColor
        default:
            return UIColor.clear.cgColor
        }
    }
    
    func changeTab(sender:UIButton) {
        if(sender.titleLabel?.text == "全部"){
            data = db.query(sql: "select * from tb_order")
        } else if (sender.titleLabel?.text == "待付款"){
            data = db.query(sql: "select * from tb_order where state='待付款'")
        } else if (sender.titleLabel?.text == "待发货"){
            data = db.query(sql: "select * from tb_order where state='待发货'")
        } else if (sender.titleLabel?.text == "待收货"){
            data = db.query(sql: "select * from tb_order where state='待收货'")
        } else if (sender.titleLabel?.text == "历史订单"){
            data = db.query(sql: "select * from tb_order where state='已收货'")
        }
        //切换按钮选中样式
        for v in tabView.subviews {
            if(v.isMember(of: UIButton.self)) {
                (v as! UIButton).isSelected = false
            }
        }
        sender.isSelected = true
        tableView.reloadData()
    }
    
    //查看商品，跳转
    func viewDetail(sender:UIButton?) {
        let secondView = OrderDetail()
        secondView.id = data[(sender?.tag)!-1000]["id"] as! Int
        secondView.price = (data[(sender?.tag)!-1000]["price"] as! String?)!
        self.hidesBottomBarWhenPushed = false
        self.navigationController?.pushViewController(secondView, animated: true)
    }
}
