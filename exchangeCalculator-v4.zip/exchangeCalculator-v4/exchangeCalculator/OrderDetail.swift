//
//  OrderDetail.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/24.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class OrderDetail:UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var id:Int = 0
    var price:String = ""
    
    var db:SQLiteDB!
    var data:[[String:Any]] = [[:]]
    var item:[String] = []
    
    var itemTableView = UITableView()
    
    let SCREEN_WIDTH = Int(UIScreen.main.bounds.width)
    let SCREEN_HEIGHT = Int(UIScreen.main.bounds.height)
    
    let H_MARGIN = 20 //横向间距
    let V_MARGIN = 5  //纵向间距
    let IMG_SIZE = 50
    let CELL_HEIGHT:CGFloat = 75.0
    
    let colorList = ColorList()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        
        db = SQLiteDB.sharedInstance
        data = db.query(sql: "select * from tb_order where id = \(id)")
        
        self.navigationItem.title = "购买商品"
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white] //标题颜色
        
        let priceLabel = UILabel(frame: CGRect(x: 20, y: 30, width: 200, height: 20))
        priceLabel.text = "总价:"+price
        priceLabel.font = UIFont.systemFont(ofSize: 16)
        
        itemTableView.dataSource=self
        itemTableView.delegate=self
        itemTableView.rowHeight = UITableViewAutomaticDimension
        itemTableView.frame = CGRect(x: 0, y: 50, width: SCREEN_WIDTH, height: SCREEN_HEIGHT)
        itemTableView.separatorStyle = UITableViewCellSeparatorStyle.none
        
        self.view.addSubview(itemTableView)
        
        item = (data[0]["item"] as! String).components(separatedBy: ";")
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item.count-1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return CELL_HEIGHT
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "td")
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        print(item[indexPath.row] as! String)
        let arr:[String] = (item[indexPath.row] as! String).components(separatedBy: ",")
        
        let imageView = UIImageView(frame: CGRect(x: 10, y: V_MARGIN, width: IMG_SIZE, height: IMG_SIZE))
        let s:String = String(describing: arr[0])
        let path = Bundle.main.path(forResource: s, ofType: "jpg")
        let newImage = UIImage(contentsOfFile: path!)
        imageView.image = newImage
        
        let lblInfo = UILabel(frame: CGRect(x: 10+IMG_SIZE, y: V_MARGIN, width: SCREEN_WIDTH-IMG_SIZE-H_MARGIN, height: 20))
        
        lblInfo.font = UIFont.systemFont(ofSize: 14)
        lblInfo.text = String(describing: arr[0])+":"+String(describing: arr[1])
        lblInfo.textColor = colorList.itemTextColor
        lblInfo.lineBreakMode = NSLineBreakMode.byClipping;
        lblInfo.numberOfLines = 0
        lblInfo.sizeToFit()
    
        
        cell.addSubview(imageView)
        cell.addSubview(lblInfo)
        
        return cell
    }

}
