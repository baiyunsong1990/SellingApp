//
//  ViewController.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/9.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UITextFieldDelegate{
    
    var db:SQLiteDB!
    
    var data:[[String:Any]] = [] //数据库数据（名称，价格）
    var commodityArr:NSMutableArray = []  //网上数据（图片，价格）
    var imgPath:[String] = []
    
    var categoryArr:[String] = []
    var tableArr:[String] = []
    
    let SCREEN_WIDTH = Int(UIScreen.main.bounds.width)
    let SCREEN_HEIGHT = Int(UIScreen.main.bounds.height)
    
    let CELL_HEIGHT:CGFloat = 76.0  //table单元格大小
    let IMG_SIZE = 60
    
    var buttonView = UIView()
    let myTableView = UITableView()
    let btnCheckout = UIButton()
    
    var quantityArr:[Int] = []  //商品数量
    var priceArr:[String] = []  //商品价格
    
    var seperator:[Int] = []  //不同分类的起始index
    var seperatorIndex = 0
    var dataCount:[Int] = [] //每组数据量
    var dataIndex = 0
    
    let colorList = ColorList()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
  
        //用户信息：姓名，电话，地址-->数据库
        let searchbar = UISearchBar(frame: CGRect(x: 40, y: 0, width: SCREEN_WIDTH-120, height: 38))
        let leftItem = UIBarButtonItem(customView: searchbar)
        self.navigationItem.leftBarButtonItem = leftItem
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "结算", style: UIBarButtonItemStyle.plain, target: self, action: #selector(checkOut(sender:)))
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "nav_bg"), for: .default)
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.tabBarController?.tabBar.backgroundColor = UIColor.darkGray
        
        searchbar.delegate = self
        
        let headSize = 60
        let buttonW = SCREEN_WIDTH/3
        let buttonH = 40
        
        
        categoryArr = ["美容保健","母婴产品","日常保健","女性保健","奶粉系列","自定义"]
        tableArr = ["beauty","maternal","healthcare","women","milkpowder","custom"]
        //分类导航
        buttonView = UIView(frame: CGRect(x: 0, y: headSize, width: SCREEN_WIDTH, height: buttonH*2+13))
        buttonView.backgroundColor = colorList.buttonBgColor
        for i in 0...1 {
            for j in 0...2 {
            let button = UIButton(frame: CGRect(x:j * (SCREEN_WIDTH/3), y: i*(buttonH)+8, width:buttonW, height: buttonH))

            button.tag = j+i*3
            button.setTitle(categoryArr[j+i*3], for:UIControlState.normal)
            button.setTitleColor(UIColor.white, for: UIControlState.normal)
            button.setTitleColor(colorList.itemTextColor, for: UIControlState.selected)
                button.backgroundColor = colorList.buttonTabColor
            button.addTarget(self, action: #selector(changeItemView(sender:)), for: .touchUpInside)
            
            buttonView.addSubview(button)
            }
        }
        self.view.addSubview(buttonView)
        //第一个tag选中
        let button:UIButton = buttonView.subviews[0] as! UIButton
        button.isSelected = true
        
        myTableView.dataSource=self
        myTableView.delegate=self
        myTableView.rowHeight = UITableViewAutomaticDimension
        myTableView.frame = CGRect(x: 10, y: 170, width: SCREEN_WIDTH-30, height: SCREEN_HEIGHT-230)
        self.view.addSubview(myTableView)
        

        let loadData = LoadData()
        //如果不存在则创建表
        loadData.createTable()
        //loadData.insertCategory()
        db = SQLiteDB.sharedInstance
        
        let count1 = db.query(sql: "select count(*) from tb_beauty")
        if(count1[0]["count(*)"] as! Int==0) {
            let mySubCategory = SubCategory()
            for i in 0..<tableArr.count {
                let subCategory = mySubCategory.getSubCategory(category: categoryArr[i])
                for sub in subCategory{
                    loadData.insertItem(category: tableArr[i], sub_category: sub)
                }
            }
        }
        
        loadData.loadOrder()
        loadData.loadUser()
        
        //initialize(quantityAppend: true)
        let allCategorylist = SubCategory()
        var count = 0
        for i in 0..<categoryArr.count {
            let subCategory = allCategorylist.getSubCategory(category: categoryArr[i])
            seperator.append(count)
            for sub in subCategory{ //二级分类数组
                let cInfo = CommodityInfo()
                let new_sub = sub.replacingOccurrences(of: " ", with: "%20")
                var cArr:NSArray = []
                cArr=(cInfo.getInfo("http://www.chemistwarehouse.com.au/search?searchtext="+new_sub+"&searchmode=allwords"))
                for c in cArr {
                    commodityArr.add(c)
                    count += 1
                }

            }
        }
        for i in 0..<tableArr.count {
            let query = db.query(sql: "select * from tb_\(tableArr[i])")
            data.append(contentsOf:query)
            dataCount.append(query.count)
        }
        
        for i in 0..<data.count {
            quantityArr.append(0)
            priceArr.append(data[i]["item_price"] as! String)
        }
        

        
        //数据库路径
        let filePath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first
        print(filePath ?? "")
    }
    
    func initialize(quantityAppend:Bool,index:Int,value:String) {
        /*data = []
        let allCategorylist = SubCategory()
        var count = 0
        for i in 0..<categoryArr.count {
            let subCategory = allCategorylist.getSubCategory(category: categoryArr[i])
            seperator.append(count)
            for sub in subCategory{ //二级分类数组
                let cInfo = CommodityInfo()
                let new_sub = sub.replacingOccurrences(of: " ", with: "%20")
                var cArr:NSArray = []
                cArr=(cInfo.getInfo("http://www.chemistwarehouse.com.au/search?searchtext="+new_sub+"&searchmode=allwords"))
                for c in cArr {
                    commodityArr.add(c)
                    count += 1
                }
                data.append(contentsOf:db.query(sql: "select * from tb_category where sub_category='\(sub)'"))
            }
        }*/
        data[index]["item_price"] = value
        priceArr[index] = value
        /*
        priceArr = []
        for i in 0..<data.count {
            if (quantityAppend) {
                quantityArr.append(0)
            }
            priceArr.append(data[i]["item_price"] as! String)
        }*/
    }
    
    func changeItemView(sender:UIButton) {
        //切换按钮选中样式
        for v in buttonView.subviews {
            if(v.isMember(of: UIButton.self)) {
                (v as! UIButton).isSelected = false
            }
        }
        sender.isSelected = true
        
        //更新commodityArr数据
        /*commodityArr = []
        db = SQLiteDB.sharedInstance
        
        let allCategorylist = SubCategory()
        let subCategory = allCategorylist.getSubCategory(category: (sender.titleLabel?.text)!)
        
        for sub in subCategory{
            let cInfo = CommodityInfo()
            let new_sub = sub.replacingOccurrences(of: " ", with: "%20")
            var cArr:NSArray = []
            cArr=(cInfo.getInfo("http://www.chemistwarehouse.com.au/search?searchtext="+new_sub+"&searchmode=allwords"))
            for c in cArr {
                commodityArr.add(c)
            }
          
        }*/
        //更新起始index

        dataIndex = sender.tag
        seperatorIndex = seperator[sender.tag]
        myTableView.reloadData()

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataCount[dataIndex]
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return CELL_HEIGHT
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let commodity:NSArray=commodityArr[indexPath.row+seperatorIndex] as! NSArray
        
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "td")
        cell.selectionStyle = UITableViewCellSelectionStyle.none //禁止cell点击事件
        
        if (commodity.count>0) {
            let myCell = CommodityCell(frame: CGRect(x: 0, y: 8, width: SCREEN_WIDTH-30, height: 65))
            
            /*let urlStr = NSURL(string: commodity[2] as! String)
             print(urlStr)
             let imgData = NSData(contentsOf: urlStr! as URL)
             print(imgData)
             let image = UIImage(data: imgData! as Data)
             print(image)
             myCell.commodityImg = UIImageView(image: image)*/
            
            myCell.lblCommodityName.text = data[indexPath.row+seperatorIndex]["item_name"] as! String?
            myCell.lblCommodityName.tag = indexPath.row + 5000
            myCell.lblCommodityName.sizeToFit()
            
            myCell.priceView.frame = CGRect(x: IMG_SIZE, y: Int(myCell.lblCommodityName.frame.height+5), width: SCREEN_WIDTH-IMG_SIZE-30, height: Int(CELL_HEIGHT-16))
            
            myCell.btnPriceFromWeb.setTitle(commodity[1] as? String, for: UIControlState.normal)
            myCell.btnPriceFromWeb.tag = indexPath.row + 100
            
            myCell.btnPriceFromWeb.addTarget(self, action: #selector(selectPrice(sender:)), for: .touchUpInside)
            
            myCell.btnPriceFromDatabase.textView.text = data[indexPath.row+seperatorIndex]["item_price"] as! String?
            myCell.btnPriceFromDatabase.textView.delegate = self
            myCell.btnPriceFromDatabase.textView.tag = indexPath.row + 3000
            myCell.btnPriceFromDatabase.tag = indexPath.row + 1000
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tap(tapGesture:)))
            myCell.btnPriceFromDatabase.addGestureRecognizer(tapGesture)
            
            myCell.btnMinus.tag = indexPath.row + 10000
            myCell.btnMinus.addTarget(self, action: #selector(changeQuantity(sender:)), for: .touchUpInside)
            myCell.lblQuantity.tag = indexPath.row + 11000
            myCell.lblQuantity.text = String(quantityArr[indexPath.row+seperatorIndex])
            myCell.btnAdd.tag = indexPath.row + 12000
            myCell.btnAdd.addTarget(self, action: #selector(changeQuantity(sender:)), for: .touchUpInside)
            
            //let urlStr = NSURL(string: String(describing: commodity[2]))
            //let imgData = NSData(contentsOf: urlStr! as URL)
            //let image = UIImage(data: imgData! as Data)
            //let commodityImg = UIImageView(image: image)
            
            //从目录导入图片
            var s:String = (data[indexPath.row+seperatorIndex]["item_name"] as! String?)!
            //s = s.replacingOccurrences(of: "\'", with: "'")
            let path = Bundle.main.path(forResource: s, ofType: "jpg")
            let newImage = UIImage(contentsOfFile: path!)
            let commodityimg = UIImageView(image: newImage)
            
            commodityimg.frame = CGRect(x: 0,y: 8,width: IMG_SIZE,height: IMG_SIZE)
            
            cell.addSubview(commodityimg)
            
            cell.addSubview(myCell)
        }
        
        return cell
    }
    
    func selectPrice(sender:UIButton?) {
        sender?.setTitleColor(UIColor.init(red: 6/255, green: 122/255, blue: 190/255, alpha: 1.0),for: .normal)
        sender?.titleLabel?.font = UIFont(name: "Snell Roundhand", size: 16)
        //let tag:NSInteger = (sender?.tag)!%100+1000
        
        /*let btnView:PriceButtonView = self.myTableView.viewWithTag(tag) as! PriceButtonView
        btnView.textView.textColor = UIColor.init(red: 117/255, green: 137/255, blue: 149/255, alpha: 1.0)
        btnView.textView.font = UIFont(name: "Snell Roundhand", size: 12)*/
        
        //let tag2:NSInteger = (sender?.tag)!%100+5000
        //let nameView:UILabel = self.myTableView.viewWithTag(tag2) as! UILabel
        
        priceArr[(sender?.tag)!-100] = (sender?.titleLabel?.text)!
        
        //btnView.textView.isEnabled = false
    }
    
    func changeQuantity(sender:UIButton?) {
        var tag:NSInteger = 10000
        var label = UILabel()
        if (sender?.titleLabel?.text == "+") {
            tag = (sender?.tag)!-1000
            label = self.myTableView.viewWithTag(tag) as! UILabel
            label.text = String(Int(label.text!)! + 1)
        } else {
            tag = (sender?.tag)!+1000
            label = self.myTableView.viewWithTag(tag) as! UILabel
            if (!(label.text=="0")) {
            label.text = String(Int(label.text!)! - 1)
            }
        }
        quantityArr[tag-11000+seperatorIndex] = Int(label.text!)!
    }
    
    func tap(tapGesture: UITapGestureRecognizer) {
        let sender:PriceButtonView = tapGesture.view as! PriceButtonView
        
        sender.textView.textColor = UIColor(red: 6/255, green: 122/255, blue: 190/255, alpha: 1.0)
        sender.textView.font = UIFont(name: "Snell Roundhand", size: 16)
        sender.textView.isEnabled = false
        
        let tag:NSInteger = (sender.tag)%1000+100
        let btnView:UIButton = self.myTableView.viewWithTag(tag) as! UIButton
        btnView.setTitleColor(UIColor.init(red: 117/255, green: 137/255, blue: 149/255, alpha: 1.0),for: .normal)
        btnView.titleLabel?.font = UIFont(name: "Snell Roundhand", size: 12)
        
        priceArr[sender.tag-1000] = (sender.textView.text)!
    }
    
    func checkOut(sender:UIBarButtonItem?) {
        let secondView = ViewCheckout()
        var arrItem:NSMutableArray = []

        for i in 0..<data.count {
            if (quantityArr[i]>0) {
                arrItem.add([data[i]["item_name"],quantityArr[i],priceArr[i]])
            }
        }

        secondView.selectedItem = arrItem
        self.hidesBottomBarWhenPushed = false
        self.navigationController?.pushViewController(secondView, animated: true)
    }
    
    // 搜索代理UISearchBarDelegate方法，每次改变搜索内容时都会调用
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {


    }
    
    //点击搜索
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        print("开始搜索")
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController: PriceButtonDelegate {
    func buttonDidTapped(button: PriceButton) {

        button.txtPrice?.textColor = UIColor.init(red: 6/255, green: 122/255, blue: 190/255, alpha: 1.0)
        button.txtPrice?.font = UIFont(name: "Snell Roundhand", size: 16)
        button.txtPrice?.isEnabled = false
        
        let tag:NSInteger = (button.tag)%1000+100
        let btnView:UIButton = myTableView.viewWithTag(tag) as! UIButton
        btnView.setTitleColor(UIColor.init(red: 117/255, green: 137/255, blue: 149/255, alpha: 1.0),for: .normal)
        btnView.titleLabel?.font = UIFont(name: "Snell Roundhand", size: 12)
        
    }
    func buttonDidlongPressed(button: PriceButton) {
        button.txtPrice?.isEnabled = true
        
    }
}
extension ViewController: UITextViewDelegate {
    //textfield结束编辑
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {

        textField.textColor = UIColor.init(red: 117/255, green: 137/255, blue: 149/255, alpha: 1.0)
        textField.font = UIFont(name: "Snell Roundhand", size: 12)
        
        let tag = textField.tag - 3000
        let tag2:NSInteger = tag+5000
        let nameView:UILabel = self.myTableView.viewWithTag(tag2) as! UILabel
        
        let tableName = tableArr[dataIndex]
        let sql="update tb_\(tableName) set item_price='\(textField.text! as String)' where item_name='\(nameView.text! as String)'"
        db.execute(sql: sql)
        
        var index = dataIndex-1
        var price_index = 0
        if(index<0) {
            price_index = 0
        } else {
            price_index = dataCount[index]
        }
        //initialize(quantityAppend: false,index: tag+price_index,value: textField.text! as String)
        
        data[tag+price_index]["item_price"] = textField.text! as String
        priceArr[tag+price_index] = textField.text! as String
        
        myTableView.reloadData()
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.isEnabled = false
        return true
    }
}

