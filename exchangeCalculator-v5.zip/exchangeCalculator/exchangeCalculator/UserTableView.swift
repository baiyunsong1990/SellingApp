//
//  TableView.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/18.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class UserTableView: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var db:SQLiteDB!
    var data:[[String:Any]] = [[:]]
    
    var dataList:[String]?
    var tableView:UITableView?
    
    let SCREEN_WIDTH = Int(UIScreen.main.bounds.width)
    let SCREEN_HEIGHT = Int(UIScreen.main.bounds.height)
    let CELL_HEIGHT:CGFloat = 70.0
    
    let loadData = LoadData()
    let colorList = ColorList()
    
    override func loadView() {
        super.loadView()
    }
    
    //进入页面前加载
    override func viewWillAppear(_ animated: Bool) {
        db = SQLiteDB.sharedInstance
        data = db.query(sql: "select * from tb_user")
        
        self.navigationItem.title = "用户管理"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "添加", style: UIBarButtonItemStyle.plain, target: self, action: #selector(add(sender:)))
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "nav_bg"), for: .default)
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.titleView?.tintColor = UIColor.white
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white] //标题颜色
        
        self.tableView = UITableView(frame: CGRect(x: 10, y: 15, width: SCREEN_WIDTH, height: SCREEN_HEIGHT-20), style: UITableViewStyle.plain)
        self.tableView!.dataSource = self;
        self.tableView!.delegate = self;
        self.tableView!.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        self.view.addSubview(tableView!)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    //返回有多少个分组
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    //每个分组对应的cell个数
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return CELL_HEIGHT
    }

    
    //创建Cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier:String = "Cell"
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath as IndexPath) as UITableViewCell
        
        let user = UserInfoCell(frame: CGRect(x: 20, y: 8, width: SCREEN_WIDTH, height: 60))
        user.lblName.text = (data[indexPath.row]["name"] as! String?)!
        user.lblID.text = (data[indexPath.row]["id"] as! String?)!
        user.lblPhone.text = (data[indexPath.row]["phone"] as! String?)!
        user.lblAddress.text = (data[indexPath.row]["address"] as! String?)!
        
        cell.addSubview(user)
        
        return cell;
    }
    
    //处理选中事件
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.tableView!.deselectRow(at: indexPath as IndexPath, animated: true)
        
        let secondView = UserEdit()
        secondView.uid = String(describing: data[indexPath.row]["uid"] ?? "")
        secondView.name = (data[indexPath.row]["name"] as! String?)!
        secondView.id = (data[indexPath.row]["id"] as! String?)!
        secondView.phone = (data[indexPath.row]["phone"] as! String?)!
        secondView.address = (data[indexPath.row]["address"] as! String?)!
        secondView.type = "update"
        
        self.hidesBottomBarWhenPushed = false
        self.navigationController?.pushViewController(secondView, animated: true)
    }
    
    //返回编辑类型，滑动删除
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        loadData.deleteUser(id: (data[indexPath.row]["id"] as! String?)!)
        return UITableViewCellEditingStyle.delete
    }
    
    //在这里修改删除按钮的文字
    func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
        return "删除"
    }
    
    //点击删除按钮的响应方法，在这里处理删除的逻辑
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete {
            self.data.remove(at: indexPath.row)
            self.tableView!.deleteRows(at: [indexPath as IndexPath], with: UITableViewRowAnimation.fade)
        }
    }
    
    func add(sender:UIBarButtonItem?)  {
        let secondView = UserEdit()
        //secondView.uid = (data[indexPath.row]["uid"] as! String?)!
        secondView.type = "insert"

        self.hidesBottomBarWhenPushed = false
        self.navigationController?.pushViewController(secondView, animated: true)
    }
}

