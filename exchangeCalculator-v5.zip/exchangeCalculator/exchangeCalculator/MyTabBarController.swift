//
//  MyTabBarController.swift
//  exchangeCalculator
//
//  Created by apple on 2016/12/21.
//  Copyright © 2016年 apple. All rights reserved.
//

import UIKit

class MyTabBarController:UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tabBar.backgroundImage = UIImage(named: "tab_bg")
        self.tabBar.tintColor = UIColor.white
    }
}
